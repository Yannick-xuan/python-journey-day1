name = input("what is your name?")
print(f"my name is {name}")
from datetime import date
today = date.today()
print(f"Today's date: {today}")

number = 7
square = number ** 2
print(f"The square of {number} is {square}")

